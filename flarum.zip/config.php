<?php return array (
  'debug' => false,
  'database' => 
  array (
    'driver' => 'mysql',
    'host' => '_host_',
    'database' => '_database_',
    'username' => '_user_',
    'password' => '_pass_',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => '',
    'port' => '3306',
    'strict' => false,
  ),
  'url' => 'https://ageno.me:_port_',
  'paths' => 
  array (
    'api' => 'api',
    'admin' => 'admin',
  ),
);